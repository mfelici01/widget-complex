using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuStart : MonoBehaviour
{
    public GameObject panelBackground;
    public  GameObject triggerpanel;
    public GameObject joystick;
    private Button button;
    // Start is called before the first frame update
    void Start()
    {
        joystick.SetActive(false);

        panelBackground.SetActive(false);

        button =GetComponent<Button>();

        button.onClick.AddListener(gameOn);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void gameOn()
    {
        joystick.SetActive(true);

        triggerpanel.SetActive(false);

        panelBackground.SetActive(true);

    }
}
