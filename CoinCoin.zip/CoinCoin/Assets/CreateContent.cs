using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class createcontent : MonoBehaviour
{
    private Button container;
    private Button newbutton;
    private Button newimage;
    private Button newrawimage;
    private Button newvideo;

    public GameObject buttonPrefab;
    public GameObject ImagePrefab;
    public GameObject rawImagePrefab;
    public GameObject VideoPlayerPrefab;

    GameObject myGameObject;

    private UI_Content_Carousel carouselScript;

    Transform parentParent;

    // Start is called before the first frame update
    void Start()
    {

        // Find the parent's parent GameObject
        parentParent = transform.parent.parent;
        if (parentParent != null)
        {
            // Find the UI_Content_Carousel script on the parent's parent GameObject
            carouselScript = parentParent.GetComponentInChildren<UI_Content_Carousel>();
            Debug.Log("UI_Content_Carousel :" + carouselScript);
        }

        if (carouselScript == null)
        {
            Debug.LogError("UI_Content_Carousel script not found in the parent's parent GameObject or its children.");
            return;
        }


        //Get the prefab buttonPrefab
        buttonPrefab = Resources.Load<GameObject>("Button (Legacy)");

        //Get the prefab ImagePrefab
        ImagePrefab = Resources.Load<GameObject>("Image");

        //Get the prefab rawImagePrefab
        rawImagePrefab = Resources.Load<GameObject>("RawImage");

        //Get the prefab VideoPlayerPrefab
        VideoPlayerPrefab = Resources.Load<GameObject>("Video Player");


        myGameObject = gameObject;


        //Get the container 
        container = myGameObject.GetComponentInChildren<Button>();
        Debug.Log("container :" + container);

        //Get the newbutton 
        newbutton = container.transform.GetChild(0).GetComponent<Button>();
        Debug.Log("newbutton :" + newbutton);


        // Add listener to newbutton
        newbutton.onClick.AddListener(AddButton);


        //Get the newimage 
        newimage = container.transform.GetChild(1).GetComponent<Button>();
        Debug.Log("newimage :" + newimage);


        // Add listener to newimage
        newimage.onClick.AddListener(AddImage);

        //Get the newrawimage 
        newrawimage = container.transform.GetChild(2).GetComponent<Button>();
        Debug.Log("newrawimage :" + newrawimage);


        // Add listener to newrawimage
        newrawimage.onClick.AddListener(AddRawImage);


        //Get the newvideo 
        newvideo = container.transform.GetChild(3).GetComponent<Button>();
        Debug.Log("newvideo :" + newvideo);


        // Add listener to newvideo
        newvideo.onClick.AddListener(AddVideo);


    }

    // Update is called once per frame
    void Update()
    {
        

    }

    public void AddButton()
    {
        // Instantiate a new button from the prefab
        GameObject newButton = Instantiate(buttonPrefab, myGameObject.transform);

        // Set its parent to the toggle panel
        newButton.transform.SetParent(myGameObject.transform, false);

        // Move the newButton to the first sibling position
        newButton.transform.SetAsFirstSibling();

        //calculate again
        carouselScript.CalculateTotalPages();
        carouselScript.InitializeNavigationDots();

    }

    public void AddImage()
    {
        // Instantiate a new image from the prefab
        GameObject newImage = Instantiate(ImagePrefab, myGameObject.transform);

        // Set its parent
        newImage.transform.SetParent(myGameObject.transform, false);

        // Move the newImage to the first sibling position
        newImage.transform.SetAsFirstSibling();

        //calculate again
        carouselScript.CalculateTotalPages();
        carouselScript.InitializeNavigationDots();
    }


    public void AddRawImage()
    {
        // Instantiate a new raw image from the prefab
        GameObject newRawImage = Instantiate(rawImagePrefab, myGameObject.transform);

        // Set its parent
        newRawImage.transform.SetParent(myGameObject.transform, false);

        // Move the newRawImage to the first sibling position
        newRawImage.transform.SetAsFirstSibling();

        //calculate again
        carouselScript.CalculateTotalPages();
        carouselScript.InitializeNavigationDots();
    }
    
    public void AddVideo()
    {
        // Instantiate a new video player from the prefab
        GameObject newVideoPlayer = Instantiate(VideoPlayerPrefab, myGameObject.transform);

        // Set its parent
        newVideoPlayer.transform.SetParent(myGameObject.transform, false);

        // Move the newVideoPlayer to the first sibling position
        newVideoPlayer.transform.SetAsFirstSibling();

        //calculate again
        carouselScript.CalculateTotalPages();
        carouselScript.InitializeNavigationDots();
    }
}
