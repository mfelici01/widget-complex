using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.UIElements;
using static UnityEngine.Rendering.VirtualTexturing.Debugging;
using Debug = UnityEngine.Debug;

public class JoystickMove : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    private RectTransform background; // L'arri�re-plan du joystick
    private RectTransform stick; // Le bouton du joystick

    public Transform perso; // objet � deplacer
    private float radius; // Rayon du joystick
    public float speed = 2.0f;

    private Vector3 move; // Direction du joystick
    private bool onJoyStick = false;


    // Start is called before the first frame update
    void Start()
    {
        background = transform.Find("Background").GetComponent<RectTransform>();
        stick = transform.Find("Background/Stick").GetComponent<RectTransform>();

        radius = background.rect.width;
    }

    // Update is called once per frame
    void Update()
    {
        perso.position += move;
    }


    void onTouch(Vector2 vecTouch)
    {
        // Calcul de la position du stick par rapport � l'arri�re-plan du joystick
        Vector2 vec = new Vector2(vecTouch.x - background.position.x, vecTouch.y - background.position.y);

        // V�rification si la position du stick d�passe les limites de l'arri�re-plan
        if (vec.magnitude > radius / 2)
        {
            vec = vec.normalized * (radius / 2);
        }

        // Mise � jour de la position du stick
        stick.position = new Vector2(background.position.x + vec.x, background.position.y + vec.y);

        // Calcul de la direction du joystick (vecteur de d�placement normalis�)
        Vector2 moveDirection = vec.normalized;

        // Calcul du mouvement en fonction de la direction et de la vitesse constante
        move = new Vector3(moveDirection.x * speed * Time.deltaTime, 0f, moveDirection.y * speed * Time.deltaTime);

        // Rotation de l'objet perso en fonction de la direction du joystick
        perso.eulerAngles = new Vector3(0f, Mathf.Atan2(moveDirection.x, moveDirection.y) * Mathf.Rad2Deg, 0f);
    }


    public void OnPointerDown(PointerEventData eventData)
    {
        onTouch(eventData.position);
        onJoyStick = true;
    }

    public void OnDrag(PointerEventData eventData)
    {
        onTouch(eventData.position);
        onJoyStick = true;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        stick.localPosition = Vector3.zero;
        onJoyStick = false;
    }
}
