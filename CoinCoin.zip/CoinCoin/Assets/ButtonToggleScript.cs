using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ButtonToggleScript : MonoBehaviour
{
    private string toggleButtonPanelName = "PanelToggle";
    public bool isButtonPanelVisible = false; // Initial state of the panel (hidden)

    public GameObject buttonPrefab;
    private Button triggerButton;
    private GameObject toggleButtonPanel; // The panel to show/hide
    private bool isButtonClicked = false;
    private Button toggleButton;
    private Button buttonplus;
    private Button buttonminus;
    private GameObject panelnewbutton;

    void Start()
    {
        //Get the prefab
        buttonPrefab = Resources.Load<GameObject>("ToggleButton");

        //Get the trigger button
        triggerButton = GetComponentInChildren<Button>();
        toggleButtonPanel = transform.Find(toggleButtonPanelName).gameObject;

        panelnewbutton = toggleButtonPanel.transform.Find("newbuttonPanel").gameObject;
        Debug.Log("panelnewbutton :" + panelnewbutton);
        //Get the ToggleButton
        toggleButton = toggleButtonPanel.GetComponentInChildren<Button>();

        //Get the button +
        buttonplus = toggleButtonPanel.transform.GetChild(1).GetComponent<Button>();
        Debug.Log("buttonplus :" + buttonplus);


        // Add listener to buttonplus
        buttonplus.onClick.AddListener(AddButton);

        //Get the button -
        buttonminus = toggleButtonPanel.transform.GetChild(2).GetComponent<Button>();
        Debug.Log("buttonminus :" + buttonminus);


        // Add listener to buttonminus
        buttonminus.onClick.AddListener(RemoveButton);


        // Hide the panel at initialization
        toggleButtonPanel.SetActive(false);
        // Add listener to triggerButton
        triggerButton.onClick.AddListener(ToggleButton);

        // Add EventTrigger component to triggerButton
        EventTrigger trigger = triggerButton.gameObject.AddComponent<EventTrigger>();

        // Create entry for PointerEnter event
        EventTrigger.Entry entryEnter = new EventTrigger.Entry();
        entryEnter.eventID = EventTriggerType.PointerEnter;
        entryEnter.callback.AddListener((data) => { ShowPanel(); });
        trigger.triggers.Add(entryEnter);

        // Create entry for PointerExit event
        EventTrigger.Entry entryExit = new EventTrigger.Entry();
        entryExit.eventID = EventTriggerType.PointerExit;
        entryExit.callback.AddListener((data) => { HidePanel(); });
        trigger.triggers.Add(entryExit);
    }

    public void ToggleButton()
    {
        isButtonPanelVisible = !isButtonPanelVisible;
        toggleButtonPanel.SetActive(isButtonPanelVisible);
        isButtonClicked = true;
    }

    void ShowPanel()
    {
        if (!isButtonClicked)
        {
            toggleButtonPanel.SetActive(true);
        }
    }

    void HidePanel()
    {
        if (!isButtonClicked)
        {
            toggleButtonPanel.SetActive(false);
        }
    }

    public void AddButton()
    {
        // Instantiate a new button from the prefab
        GameObject newButton = Instantiate(buttonPrefab, panelnewbutton.transform);
        
        // Set its parent to the toggle panel
        newButton.transform.SetParent(panelnewbutton.transform, false);

       
    }

    public void RemoveButton()
    {
        // Find the last button in the toggle panel
        Transform lastButton = panelnewbutton.transform.GetChild(panelnewbutton.transform.childCount - 1);

            // Destroy it
            Destroy(lastButton.gameObject);
    }
}
