using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RED : MonoBehaviour
{
    private Button button;
    private Image buttonImage;
    public GameObject cube;
    private Renderer cubeRenderer;
    public GameObject panelbackground;

    void Start()
    {
        // Obtenez le composant Renderer du cube
        cubeRenderer = cube.GetComponent<Renderer>();

        // Obtenez le composant Button de ce GameObject
        button = GetComponent<Button>();

        // Obtenez le composant Image du bouton
        buttonImage = button.GetComponent<Image>();

        // Ajoutez un �couteur de clic au bouton
        button.onClick.AddListener(ChangeCubeColor);
    }

    public void ChangeCubeColor()
    {
        // Obtenez la couleur du bouton
        Color buttonColor = buttonImage.color;

        // Modifiez la couleur du mat�riau du cube
        cubeRenderer.material.color = buttonColor;

        // D�sactivez le panneau arri�re-plan
        panelbackground.SetActive(false);
    }
}
