using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSpawn : MonoBehaviour
{
    public GameObject prefabFood; // Le prefab � faire appara�tre
    public float spawnInterval = 5f; // Intervalle de temps entre chaque apparition
    public Transform duck;
    private GameObject food;
    public int Gap = 10;

    public GameObject child;
    private List<GameObject> Body = new List<GameObject>();
    private List<Vector3> BodyPos = new List<Vector3>();


    private float timer = 0f; // Compteur de temps

    // Start is called before the first frame update
    private void Start()
    {
        // R�cup�rer le collider du terrain
        SpawnPrefab();
    }


    // Update is called once per frame
    void Update()
    {
        // Incr�menter le compteur de temps
        timer += Time.deltaTime;

        // V�rifier si le temps �coul� d�passe l'intervalle de spawn
        if (timer >= spawnInterval)
        {
            // R�initialiser le compteur de temps
            timer = 0f;

            // Appeler la fonction de spawn
            //SpawnPrefab();
            MoveFood();
        }

        // V�rifier si la position du canard est proche de celle du food
        if (food && Vector3.Distance(duck.position, food.transform.position) < 2f)
        {
            MoveFood();
            GrowDuck();
        }

        UpdateBodyPositions();
    }

    void SpawnPrefab()
    {
        // G�n�rer une position al�atoire sur le cube
        Vector3 randomPosition = GetRandomPositionOnCube();

        // Faire appara�tre le prefab � la position g�n�r�e
        food = Instantiate(prefabFood, randomPosition, Quaternion.identity);

    }

    Vector3 GetRandomPositionOnCube()
    {
        // R�cup�rer les dimensions du cube
        Vector3 cubeSize = transform.localScale;

        float rangeMultiplier = 9f;

        // G�n�rer des coordonn�es x, y et z al�atoires sur le cube
        float randomX = Random.Range(-cubeSize.x / 2f * rangeMultiplier, cubeSize.x / 2f * rangeMultiplier);
        float randomY = 0.5f;
        float randomZ = Random.Range(-cubeSize.z / 2f * rangeMultiplier, cubeSize.z / 2f * rangeMultiplier);

        Debug.Log("Position de l'objet : " + randomX + " " + randomY + " " + randomZ);

        // Construire le vecteur de position avec les coordonn�es x, y et z
        Vector3 randomPosition = transform.position + new Vector3(randomX, randomY, randomZ);

        return randomPosition;
    }

    void MoveFood()
    {
        // D�placer le food � une nouvelle position
        Vector3 randomPosition = GetRandomPositionOnCube();
        food.transform.position = randomPosition;
    }

    private void GrowDuck()
    {
        GameObject body = Instantiate(child);
        Body.Add(body);
    }

    private void UpdateBodyPositions()
    {
        // Ins�rer la position actuelle du canard dans la liste des positions du corps
        BodyPos.Insert(0, duck.position);

        // Mettre � jour la position de chaque corps en fonction de la position enregistr�e dans BodyPos
        for (int i = 0; i < Body.Count; i++)
        {
            int targetIndex = Mathf.Clamp((i + 1) * Gap, 0, BodyPos.Count - 1);
            Vector3 targetPosition = BodyPos[targetIndex];

            // D�placer le corps vers la position cible
            Body[i].transform.position = Vector3.Lerp(Body[i].transform.position, targetPosition, Time.deltaTime * 10f);

            // Orienter le corps vers la position cible
            Body[i].transform.LookAt(targetPosition);
        }
    }

}
